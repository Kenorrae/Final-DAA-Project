//----------------------------------------------------------------------------------------------------------------------
// Functions for Login Page

//Login function
function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => { throw new Error(err.error); });
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            window.location.href = '/LagoonWebsite/Browse';
        } else {
            alert('Invalid credentials. Please try again.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert(`Error: ${error.message}`);
    });
}


// conceal password
document.getElementById("eyeicon").onclick = function() {
    let password = document.getElementById("password");
    if (password.type === "password") {
        password.type = "text";
        document.getElementById("eyeicon").src = "/images/openeye.png";
    } else {
        password.type = "password";
        document.getElementById("eyeicon").src = "/images/closeeye.png";
    }
}

//----------------------------------------------------------------------------------------------------------------------
// Functions for Browse Page, Cart, Purchase history

function viewstalls() {
    const stallGrid = document.querySelector('.stall-grid');
    stallGrid.classList.remove('hidden');
    
    const itemGrid = document.querySelector('.item-grid');
    itemGrid.classList.add('hidden');

}








