let sortby = 'ItemName';
let queryby = '';
let currentstallID = 0;
let cart = [];
let isReversed = false;

function checkCartContents(number) {
    let pair = cart.find(pair => pair[0] === number);
    return pair ? pair[1] : 0;
}
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//======================================================================================================================
// retrieves the contents of the cart file
// executed as soon as browsepage is loaded
// for the page to know what items are in your cart as of the moment
async function retrieveCartContents(){
    const username = await retrieveUsername(); // Await the promise to get the actual username
    console.log('retrieve items from Cart'); // Debugging statement
    try {
        const response = await fetch(`/api/itemfromcart?username=${username}`);
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Items fetched:', data); // Debugging statement

        if (data.length === 0) {
            console.log('No items found for the given search string'); // Debugging statement
            return;
        }

        data.forEach(item => {
            cart.push([item.ItemID, item.quantity]);
            console.log(" ", item.itemName, " was Add");
        });                                          

    } catch (error) {
        console.error('Error fetching items:', error);
    }
}


//----------------------------------------------------------------------------------------------------------------------
//selects the method of sorting the data (either alphabetically or by price)
function setsortkey(key, reversedState){
    if(key !== sortby){
        sortby = key;
        if (queryby === 'stallID'){
            fetchAndRenderItembyID(currentstallID, key);
        }
        else if  (queryby === 'searchString'){
            const searchBox = document.getElementById('searchBox');
            const initialSearchString = searchBox.value.trim();

            fetchAndRenderItembyStringSearch(initialSearchString, key);
        }    
    }

    if(reversedState !== isReversed){
        isReversed = reversedState;
        if (queryby === 'stallID'){
            fetchAndRenderItembyID(currentstallID, key);
        }
        else if  (queryby === 'searchString'){
            const searchBox = document.getElementById('searchBox');
            const initialSearchString = searchBox.value.trim();

            fetchAndRenderItembyStringSearch(initialSearchString, key);
        }    
    }
}

// Merge Sort
function mergeSort(array, key) {
    if (array.length <= 1) {
        return array;
    }

    const middle = Math.floor(array.length / 2);
    const left = array.slice(0, middle);
    const right = array.slice(middle);

    return merge(
        mergeSort(left, key),
        mergeSort(right, key),
        key
    );
}

function merge(left, right, key) {
    let resultArray = [], leftIndex = 0, rightIndex = 0;

    while (leftIndex < left.length && rightIndex < right.length) {
        if (key === 'ItemName') {
            if (left[leftIndex][key].toLowerCase() < right[rightIndex][key].toLowerCase()) {
                resultArray.push(left[leftIndex]);
                leftIndex++;
            } else {
                resultArray.push(right[rightIndex]);
                rightIndex++;
            }
        } else {
            if (left[leftIndex][key] < right[rightIndex][key]) {
                resultArray.push(left[leftIndex]);
                leftIndex++;
            } else {
                resultArray.push(right[rightIndex]);
                rightIndex++;
            }
        }
    }

    return resultArray.concat(left.slice(leftIndex)).concat(right.slice(rightIndex));
}

//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------



//======================================================================================================================
// Display items in the sorted list (sorted by merge sort)
async function fetchandRenderItemsfromCart(username) {
    console.log('fetchAndRenderItems function called from cart'); // Debugging statement
    try {
        const response = await fetch(`/api/itemfromcart?username=${username}`);
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Items fetched:', data); // Debugging statement

        if (data.length === 0) {
            console.log('No items found for the given search string'); // Debugging statement
            return;
        }

        // Await the async displayItemsWithQuantities function
        await displayItemsWithQuantities(data, "Result", "auto");
    } catch (error) {
        console.error('Error fetching items:', error);
    }
}

async function fetchImageById(id) {
    const response = await fetch(`http://localhost:3000/image/${id}`, {
        method: 'GET'
    });

    if (!response.ok) {
        throw new Error('Network response was not ok ' + response.statusText);
    }

    const imageBlob = await response.blob();
    const imageUrl = URL.createObjectURL(imageBlob);
    console.log(imageUrl);
    return imageUrl;
}

//======================================================================================================================
//======================================= GROUP ITEMS PER STALL =======================================================
//======================================================================================================================
// Function to fetch and render stalls
async function fetchAndRenderStalls() {
    console.log('fetchAndRenderStalls function called'); // Debugging statement
    const response = await fetch('/api/stalls');
    const data = await response.json();
    console.log('Stall data fetched:', data); // Debugging statement
    const stallGrid = document.querySelector('.stall-grid');
    stallGrid.innerHTML = ''; // Clear existing stalls

    for (const stall of data) {
        const stallField = document.createElement('div');
        stallField.className = 'stallfield';
        
        // Fetch the image URL asynchronously
        const imageURL = await fetchImageById(stall.StallID);
        

        const stallFrame = document.createElement('button');
        stallFrame.className = 'stallframe btn';
        stallFrame.style.backgroundImage = `url(${imageURL})`;
        stallFrame.textContent = `Stall ${stall.StallNumber} - ${stall.StallName}`;
        stallFrame.addEventListener('click', () => openStall(stall.StallID));

        stallField.appendChild(stallFrame);
        stallGrid.appendChild(stallField);
    }
}

//======================================================================================================================
// Switches from stall display to item display (used by buttons per stall)
function openStall(stallID) {
    queryby = 'stallID';
    currentstallID = stallID;
    console.log("currentstallID" + currentstallID);

    const stallGrid = document.querySelector('.stall-grid');
    stallGrid.classList.add('hidden');
    
    const itemGrid = document.querySelector('.item-grid');
    itemGrid.classList.remove('hidden');

    fetchAndRenderItembyID(stallID);
}
//======================================================================================================================
// Function to fetch and render items Per stall
async function fetchAndRenderItembyID(stallID, sortingkey) {
    console.log('fetchAndRenderItems function called with StallID:', stallID);
    try {
        const response = await fetch(`/api/itemsbyID?stallID=${stallID}`);
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Items fetched:', data);
        const itemGrid = document.querySelector('.item-grid');
        itemGrid.innerHTML = ''; // Clear existing items

        if (data.length === 0) {
            console.log('No items found for the given StallID');
            return;
        }

        // Filter, sort, and display items for different categories
        await filterSortDisplayItems(data, 'Beverage', 'BEVERAGES', sortingkey);
        await filterSortDisplayItems(data, 'Food', 'FOOD', sortingkey);
        await filterSortDisplayItems(data, 'Dessert', 'DESSERTS', sortingkey);
        await filterSortDisplayItems(data, 'Food and Drink Combo', 'FOOD AND DRINK COMBO', sortingkey);
        await filterSortDisplayItems(data, 'Add-on', 'ADD-ONS', sortingkey);
    } catch (error) {
        console.error('Error fetching items:', error);
    }
}


//======================================================================================================================
//======================================================================================================================
//======================================================================================================================





//======================================================================================================================
//====================================== GROUP ITEMS BASED ON SEARCHBAR ================================================
//======================================================================================================================
//Switches from stall display to item display (used when searching)
function produceresults(initialSearchString, sortingKey) {
    queryby = 'searchString';
    const stallGrid = document.querySelector('.stall-grid');
    stallGrid.classList.add('hidden');
    
    const itemGrid = document.querySelector('.item-grid');
    itemGrid.classList.remove('hidden');

    fetchAndRenderItembyStringSearch(initialSearchString, sortingKey);
}

//======================================================================================================================
// Function to fetch and render items using the search bar above

async function fetchAndRenderItembyStringSearch(initialSearchString, sortingKey) {
    console.log('fetchAndRenderItems function called with searchstring:', initialSearchString); // Debugging statement

    try {
        const response = await fetch('/api/itembysearchstring');
        
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.statusText}`);
        }

        const data = await response.json();
        console.log('Items fetched:', data); // Debugging statement
        
        // Inspect data structure
        data.forEach(item => {
            if (!item.ItemName || typeof item.ItemName !== 'string') {
                console.warn('Invalid item structure:', item);
            }
        });

        // Filter the items based on the search string
        const filteredData = filterListByName(data, initialSearchString);
        const itemGrid = document.querySelector('.item-grid');
        itemGrid.innerHTML = ''; // Clear existing items

        if (filteredData.length === 0) {
            console.log('No items found for the given search string'); // Debugging statement
            return;
        }

        // Await the async filterSortDisplayItems function
        await filterSortDisplayItems(filteredData, 'all', 'RESULTS', sortingKey );
        
    } catch (error) {
        console.error('Error fetching items:', error);
    }
}

//======================================================================================================================
//Filter list by itemname (when using the search bar)
function filterListByName(list, searchString) {

    // Convert the search string to lowercase for case-insensitive search
    const lowerCaseSearchString = searchString.toLowerCase();

    // Filter the list to include only items whose name contains the search string
    const filteredList = list.filter(item => {
        if (item.ItemName && typeof item.ItemName === 'string') {
            return item.ItemName.toLowerCase().includes(lowerCaseSearchString);
        } else {
            console.warn('Item with missing or invalid itemname property:', item);
            return false;
        }
    });

    return filteredList;
}

//======================================================================================================================
//======================================================================================================================
//======================================================================================================================




//======================================================================================================================
//==================== REMOVE UNWANTED ITEMTYPES, SORT ALPHABETICALLY/BY PRICE, DISPLAY RESULTS ========================
//======================================================================================================================
// Filter list by itemtype
function filterItemsByType(items, itemType) {
    return items.filter(item => item.ItemType === itemType);
}

//======================================================================================================================
// Used by both search by itemname and  display per stall

async function filterSortDisplayItems(data, itemType, title, sortingKey) {
    let FilteredItems;

    if (itemType === 'all') {
        FilteredItems = data;
    } else {
        FilteredItems = filterItemsByType(data, itemType);
    }
    
    if (FilteredItems.length > 0) {
        // Sort data by the provided sortingKey
        const sortedItems = mergeSort(FilteredItems, sortingKey);
        if (isReversed) {
            sortedItems.reverse();
        }
        console.log('sorted items');

        // Display sorted data
        await displayItemsWithQuantities(sortedItems, title, itemType);
    } else {
        console.log("the size is zero");
    }
}


async function determineICON(itemType){
    console.log(itemType);
    let iconUrl = "";
    switch (itemType){
        case "Beverage":
           console.log("inumin"); 
           return "http://localhost:3000/itemicon/BEVERAGE.png";
        case "Food":
            console.log("pambara");     
            return "http://localhost:3000/itemicon/FOOD.png";   
        case "Food and Drink Combo":
            console.log("downforward 1 + 2");
            return "http://localhost:3000/itemicon/COMBO.png";   
        case "Dessert":  
            console.log('gutom pa');
            return "http://localhost:3000/itemicon/DESSERTS.png";
        case "Add-on":
            console.log('designer ng pagkain');
            return "http://localhost:3000/itemicon/ADDONS.png"; 

    }

    
}

//======================================================================================================================
// Designer for Display
async function displayItemsWithQuantities(items, titleText, itemType) {
        const itemGrid = document.querySelector('.item-grid');
        let segmentTitle = document.createElement('div');
        segmentTitle.classList.add('segment-title');
        segmentTitle.textContent = titleText;
        await itemGrid.appendChild(segmentTitle);
    
        for (const item of items) {
            const itemField = document.createElement('div');
            itemField.className = 'item';
    
            const imageContainer = document.createElement('div');
            imageContainer.className = 'image-container';
    
            const priceContainer = document.createElement('div');
            priceContainer.className = 'price-container';
    
            const descriptionContainer = document.createElement('div');
            descriptionContainer.className = 'description-container';
    
            const addButtonContainer = document.createElement('div');
            addButtonContainer.className = 'add-button-container';
    
            const image = document.createElement('img');
            image.className = 'item-image';
            let iconURL;
            if (itemType === "auto"){
                iconURL = await determineICON(item.itemtype);
            }
            else if  (itemType === "all"){
                iconURL = await determineICON(item.ItemType);
            }
            else{
                iconURL = await determineICON(itemType);
            }
            
            image.src = iconURL;
    
            const priceSymbol = document.createElement('span');
            priceSymbol.className = 'currency-symbol';
            priceSymbol.textContent = '₱';
    
            const price = document.createElement('span');
            price.className = 'price';
            price.textContent = item.Price;
    
            const itemName = document.createElement('h2');
            itemName.className = 'item-title';
            itemName.textContent = item.ItemName;
    
            const itemLore = document.createElement('p');
            itemLore.className = 'item-lore';
            itemLore.textContent = item.ItemDesc;
    
            const addButton = document.createElement('button');
            addButton.addEventListener('click', () => {
                increaseQuantity(item.ItemID, 1, quantityDisplay); // Pass the quantityDisplay element
            });
    
            addButton.className = 'toggle-quantity-button';
            addButton.textContent = '+';
    
            const quantityDisplay = document.createElement('div');
            quantityDisplay.className = "quantity-display";
            quantityDisplay.textContent = String(item.quantity); // Set the initial quantity
            if (String(item.quantity) === "undefined") {
                console.log("quantity unidentifed");
                const itemCount = checkCartContents(item.ItemID);
                quantityDisplay.textContent = String(itemCount); // Set the initial quantity
            }
            console.log(String(item.quantity));
    
            const subtractButton = document.createElement('button');
            subtractButton.addEventListener('click', () => {
                decreaseQuantity(item.ItemID, 1, quantityDisplay); // Pass the quantityDisplay element
            });
            subtractButton.className = 'toggle-quantity-button';
            subtractButton.textContent = '-';
    
            imageContainer.appendChild(image);
            priceContainer.appendChild(priceSymbol);
            priceContainer.appendChild(price);
            descriptionContainer.appendChild(itemName);
            descriptionContainer.appendChild(itemLore);
            addButtonContainer.appendChild(subtractButton);
            addButtonContainer.appendChild(quantityDisplay);
            addButtonContainer.appendChild(addButton);
    
            itemField.appendChild(imageContainer);
            itemField.appendChild(priceContainer);
            itemField.appendChild(descriptionContainer);
            itemField.appendChild(addButtonContainer);
    
            await itemGrid.appendChild(itemField);
        }
    }
    


//======================================================================================================================
//======================================================================================================================
// Increase Quantity of item in cart
async function increaseQuantity(itemID, clientquantity, quantityDisplay) {
    try {
        const username = await retrieveUsername();
        const quantity = await checkQuantity(username, itemID);
        const price = await checkPrice(itemID);
        const totalquantity = quantity + clientquantity;
        const totalprice = price * totalquantity;

        if (quantity === 0) {
            await insertData(itemID, totalquantity, totalprice);
            console.log('1 item inserted');
        } else {
            await updateData(itemID, totalquantity, totalprice);
            console.log('+ 1 item successful');
        }
        quantityDisplay.textContent = totalquantity; // Update the display

        
        if (currentpage() === "cart"){
            evaluateTotalPrice()
        }
        
    } 
    
    catch (error) {
        console.error('Error increasing quantity:', error);
    }
}

//======================================================================================================================
// Decrease Quantity of item in cart 
async function decreaseQuantity(itemID, reducequantity, quantityDisplay) {
    try {
        const username = await retrieveUsername();
        const quantity = await checkQuantity(username, itemID);
        const price = await checkPrice(itemID);
        const totalquantity = quantity - reducequantity;
        const totalprice = price * totalquantity;

        if (totalquantity > 0) {
            await updateData(itemID, totalquantity, totalprice);
            console.log('- 1 item successful');
            quantityDisplay.textContent = totalquantity; // Update the display
        } else {
            await deleteData(itemID);
            console.log('- 1 item successful');
            quantityDisplay.textContent = 0; // Update the display
            
        }
        if (currentpage() === "cart"){
            evaluateTotalPrice()
        }
        
        
    } catch (error) {
        console.error('Error decreasing quantity:', error);
    }
}

//======================================================================================================================
//Check Quantity of item
// used by both increaseQuantity and DecreaseQuantity
async function checkQuantity(username, itemID) {
    return fetch(`/checkquantity?username=${username}&itemID=${itemID}`, {
        method: 'GET'
    })
    .then(response => response.json())
    .then(data => {
        console.log('quantity fetched:', data.quantity); // Debugging statement
        return data.quantity;
    })
    .catch(error => {
        console.error('Error:', error);
        return 0; // In case of an error, return 0
    });
}


//======================================================================================================================
//======================================================================================================================
// after using checkquantity, both Increase and decrease functions use either of the 3 exampls bellow to edit the data in the cart file
//======================================================================================================================
// Example of inserting data
async function insertData(itemID, quantity, totalprice) {
    try {
        const username = await retrieveUsername();
        const response = await fetch('/insert', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, itemID, quantity, totalprice })
        });
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error inserting data:', error);
    }
}

//======================================================================================================================
// Example of updating data
async function updateData(itemID, quantity, totalprice) {
    try {
        const username = await retrieveUsername();
        const response = await fetch('/update', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, itemID, quantity, totalprice })
        });
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error updating data:', error);
    }
}


//======================================================================================================================
// Example of deleting data
async function deleteData(itemID) {
    try {
        const username = await retrieveUsername();
        const response = await fetch('/delete', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, itemID })
        });
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error('Error deleting data:', error);
    }
}



//======================================================================================================================
// used by 
function retrieveUsername() {
    return fetch('/api/getUsername')
        .then(response => response.json())
        .then(data => {
            if (data.username) {
                console.log('Logged in as:', data.username);
                return data.username;
            } else {
                console.error('User not authenticated');
                throw new Error('User not authenticated');
            }
        })
        .catch(error => {
            console.error('Error fetching username:', error);
            throw error;
        });
}

//======================================================================================================================
// Check Price of item
async function checkPrice(itemID) {
    try {
        const response = await fetch(`/checkprice?itemID=${itemID}`);
        const data = await response.json();
        console.log('price fetched:', data.price); // Debugging statement
        return data.price;
    } catch (error) {
        console.error('Error:', error);
        return 0; // In case of an error, return 0
    }
}









