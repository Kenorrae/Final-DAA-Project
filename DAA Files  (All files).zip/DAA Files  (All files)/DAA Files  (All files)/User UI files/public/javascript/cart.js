let Totalpriceinsidecart;

//======================================================================================================================
// if increase and decrease buttons are pressed, the respective page/s know to alter the data inside cart file in MySQL
function currentpage(){
    return "cart";
}
//======================================================================================================================
// Updates the total price displayed in the cart.html
async function evaluateTotalPrice() {
    const username = await retrieveUsername();
    console.log('retrieve items from Cart'); // Debugging statement
    try {
        const response = await fetch(`/api/itemfromcart?username=${username}`);
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Items fetched:', data); // Debugging statement

        if (data.length === 0) {
            console.log('No items found for the given search string'); // Debugging statement
            const totalpricecontainer = document.querySelector(".total-price-container");
            totalpricecontainer.textContent = `₱ 0`;
            return;
        }

        Totalpriceinsidecart = 0;
        data.forEach(item => {
            Totalpriceinsidecart += item.totalprice;
        });

        const totalpricecontainer = document.querySelector(".total-price-container");
        totalpricecontainer.textContent = `₱${Totalpriceinsidecart}`;

    } catch (error) {
        console.error('Error fetching items:', error);
    }
}

//======================================================================================================================
// reveals itemGrid, collates cart items, evaluates total price
document.addEventListener('DOMContentLoaded', () => {
    const itemGrid = document.querySelector('.item-grid');
    itemGrid.classList.remove('hidden');

    onStartup();
    evaluateTotalPrice();
});

//======================================================================================================================
// run fetchandRenderItemsfromCart from fetch.js
async function onStartup() {
    try {
        const username = await retrieveUsername();
        await fetchandRenderItemsfromCart(username);
    } catch (error) {
        console.error('Error during startup:', error);
    }
}


