function currentpage(){
    return "browser";
}


//======================================================================================================================
//Display stall using Function fetchandrenderstalls in fetch.js
//Hides the itemGrid
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded event fired'); // Debugging statement
    fetchAndRenderStalls();

    const itemGrid = document.querySelector('.item-grid');
    itemGrid.classList.add('hidden');

});

//======================================================================================================================
// onclick function of Search button
document.addEventListener('DOMContentLoaded', () => {
    const searchButton = document.getElementById('searchButton');
    const searchBox = document.getElementById('searchBox');

    if (searchButton) {
        searchButton.addEventListener('click', () => {
            const initialSearchString = searchBox.value.trim();
            const sortingKey = sortby;
            if (initialSearchString) {
                produceresults(initialSearchString, sortingKey);
            } else {
                alert("Please enter a search term.");
            }
        });
    } else {
        console.error('Search button not found');
    }
});

//======================================================================================================================
// retrieve cart contents

document.addEventListener('DOMContentLoaded', () => {
    retrieveCartContents();
});