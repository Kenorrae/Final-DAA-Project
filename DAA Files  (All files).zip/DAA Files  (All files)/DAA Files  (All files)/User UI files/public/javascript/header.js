document.addEventListener('DOMContentLoaded', function() {
    const headerContainer = document.createElement('div');
    fetch('/header.html')
        .then(response => response.text())
        .then(data => {
            headerContainer.innerHTML = data;
            document.body.prepend(headerContainer);

            const logoutButton = document.getElementById('logoutButton');
            const browseButton = document.getElementById('browseButton');
            const cartButton = document.getElementById('cartButton');

            if (logoutButton) {
                logoutButton.onclick = function() {
                    fetch('/logout', {
                        method: 'POST',
                        credentials: 'include' // include cookies in the request
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            window.location.href = '/LagoonWebsite/Login';
                        } else {
                            alert('Logout failed');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
                };
            } else {
                console.error('Logout button not found');
            }

            if (browseButton) {
                browseButton.onclick = function() {
                    window.location.href = '/LagoonWebsite/Browse';
                };
            }

            if (cartButton) {
                cartButton.onclick = function() {
                    window.location.href = '/LagoonWebsite/PersonalCart';
                };
            }
        })
        .catch(error => console.error('Error loading header:', error));
});