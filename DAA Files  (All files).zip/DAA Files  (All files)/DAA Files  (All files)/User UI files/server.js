//==========================================================================================================================
// imports in use
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');                                                                 // MySQL
const path = require('path');                                                                   
const cors = require('cors');                                                                   // imports for website security
const session = require('express-session');


//==========================================================================================================================
const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static('public'));

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: false, // Set to true if using HTTPS
        maxAge: 30 * 60 * 1000 // Session expires after 30 minutes of inactivity
    }
}));

//==========================================================================================================================
// Creates connection to database (MySQL)
const db = mysql.createConnection({
    host: 'localhost',
    user: 'arron',
    password: 'newpassword1',
    database: 'food_stalls_database'
});


db.connect(err => {
    if (err) {
        console.error('Database connection error:', err);
    } else {
        console.log('Database connected');
    }
});

//==========================================================================================================================
// Middleware to check if the user is authenticated
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next();
    } else {
        res.redirect('/LagoonWebsite/Login');
    }
}

//==========================================================================================================================
// API endpoint to validate user credentials
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT * FROM accounts WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).json({ error: `Error retrieving users: ${err.message}` });
        } else if (results.length > 0) {
            req.session.user = username; // Save user session
            res.json({ success: true, redirectUrl: '/LagoonWebsite/Browse' });
        } else {
            res.status(401).json({ error: 'Invalid credentials' });
        }
    });
});


//==========================================================================================================================
// Logout endpoint to destroy user session
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Failed to logout' });
        }
        res.json({ success: true });
    });
});

//==========================================================================================================================
// Endpoint to fetch stalls
app.get('/api/stalls', isAuthenticated, (req, res) => {
    const query = 'SELECT * FROM stalls';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error retrieving stalls:', err);
            res.status(500).json({ error: `Error retrieving stalls: ${err.message}` });
        } else {
            console.log("recieved stalls");
            res.json(results);
        }
    });
});

// Endpoint to get image by ID
app.get('/image/:id', isAuthenticated,(req, res) => {
    const id = req.params.id;
    const sql = "SELECT path FROM images WHERE StallID = ?";
    db.query(sql, [id], (err, result) => {
        if (err) throw err;
        if (result.length === 0) return res.status(404).send('Image not found.');

        const imagePath = path.join(__dirname, 'public', result[0].path);
        res.sendFile(imagePath);
    });
});

//==========================================================================================================================
// Endpoint to fetch items by id
app.get('/api/itemsbyID', isAuthenticated, (req, res) => {
    const stallID = req.query.stallID;
    console.log('Received request to fetch items with StallID:', stallID); // Debugging statement

    const query = 'SELECT * FROM food_stalls_database.itemlist WHERE StallID = ?;';
    db.query(query, [stallID], (err, results) => {
        if (err) {
            console.error('Error retrieving items:', err);
            res.status(500).json({ error: 'Error retrieving items: ${err.message}' });
        } 
        else {
            console.log('Items retrieved from database:', results); // Debugging statement
            res.json(results);
        }
    });
});

//==========================================================================================================================
// Endpoint to fetch items searching in itemlist
app.get('/api/itembysearchstring', isAuthenticated, (req, res) => {
    const searchstring = req.query.searchstring;
    console.log('Received request to fetch items with searchstring', searchstring); // Debugging statement

    const query = "SELECT * FROM food_stalls_database.itemlist;";
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error retrieving items:', err);
            res.status(500).json({ error: `Error retrieving items: ${err.message}` });
        } else {
            console.log('Items retrieved from database:', results); // Debugging statement
            res.json(results);
        }
    });
});

//==========================================================================================================================
// Endpoint to fetch items searching in cart database
app.get('/api/itemfromcart', isAuthenticated, (req, res) => {
    const username = req.query.username;
    console.log('Received request to fetch items from personal cart of ' + username); // Debugging statement

    const query = `
        SELECT c.ItemID, it.ItemName, it.Price, it.itemtype, c.quantity, c.totalprice 
        FROM cart as c 
        JOIN itemlist as it 
        ON c.ItemID = it.ItemID 
        WHERE c.username = ?
    `;
    db.query(query, [username], (err, results) => {
        if (err) {
            console.error('Error retrieving items:', err);
            res.status(500).json({ error: `Error retrieving items: ${err.message}` });
        } else {
            console.log('Items retrieved from database:', results); // Debugging statement
            res.json(results);
        }
    });
});

//==========================================================================================================================
// Endpoint to check quantity
app.get('/checkquantity', (req, res) => {
    const { username, itemID } = req.query; // Use req.query instead of req.body for GET requests

    const query = 'SELECT quantity FROM food_stalls_database.cart WHERE username = ? AND itemID = ?';
    db.query(query, [username, itemID], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (result.length === 0) {
            res.status(200).json({ quantity: 0 });
        } else {
            res.status(200).json({ quantity: result[0].quantity });
        }
    });
});

//==========================================================================================================================
// Endpoint to checkprice
app.get('/checkprice', (req, res) => {
    const { itemID } = req.query; // Use req.query instead of req.body for GET requests

    const query = 'SELECT price FROM food_stalls_database.itemlist WHERE itemID = ?';
    db.query(query, [itemID], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (result.length === 0) {
            res.status(365).json({ error: err.message });
        } else {
            res.status(200).json({ price: result[0].price });
        }
    });
});

//==========================================================================================================================
// Endpoint to insert data
app.post('/insert', (req, res) => {
    const { username, itemID, quantity, totalprice } = req.body;

    const query = 'INSERT INTO food_stalls_database.cart (username, itemID, quantity, totalprice) VALUES (?, ?, ?, ?)';
    db.query(query, [username, itemID, quantity, totalprice], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.status(200).json({ message: 'Data inserted successfully', result });
        }
    });
});

//==========================================================================================================================
// Endpoint to update data
app.put('/update', (req, res) => {
    const { username, itemID, quantity, totalprice } = req.body;

    const query = 'UPDATE food_stalls_database.cart SET quantity = ?, totalprice = ? WHERE username = ? AND itemID = ? ';
    db.query(query, [quantity, totalprice, username, itemID], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.status(200).json({ message: 'Data updated successfully', result });
        }
    });
});

//==========================================================================================================================
// Endpoint to delete data
app.delete('/delete', (req, res) => {
    const { username, itemID } = req.body;

    const query = 'DELETE FROM food_stalls_database.cart WHERE username = ? AND itemID = ?';
    db.query(query, [username, itemID], (err, result) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.status(200).json({ message: 'Data deleted successfully', result });
        }
    });
});



// Serve the login page without authentication
app.get('/LagoonWebsite/Login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'loginpage.html'));
});

// Protect all other routes with authentication middleware
app.get('/LagoonWebsite/Browse', isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'browsepage.html'));
});

// Protect all other routes with authentication middleware
app.get('/LagoonWebsite/PersonalCart', isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'cart.html'));
});




app.get('/api/getUsername', (req, res) => {
    if (req.session.user) {
        res.json({ username: req.session.user });
    } else {
        res.status(401).json({ error: 'Not authenticated' });
    }
});

//==========================================================================================================================
app.listen(3000, () => {
    console.log('Server running on port 3000');
});
